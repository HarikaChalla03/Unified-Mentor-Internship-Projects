Use roadaccidents;
-- SELECT `Million Plus Cities`, SUM(`Count`) AS total
       --  FROM road_accident
		-- GROUP BY `Million Plus Cities`
		-- ORDER BY total DESC
      
-- SELECT SUM(Count) AS total_accidents FROM road_accident 
          
-- SELECT `Cause Category`,SUM(`Count`) AS total
          -- FROM road_accident
		  -- GROUP BY `Cause Category`
		  -- ORDER BY total DESC
            
-- SELECT `Cause Subcategory`, SUM(`Count`) AS total
           --  FROM road_accident
		    -- GROUP BY `Cause Subcategory`
            --  ORDER BY total DESC
            --  LIMIT 5
-- SELECT `Outcome of Incident`, SUM(`Count`) AS total
            -- FROM road_accident
            -- GROUP BY `Outcome of Incident`
            -- ORDER BY total DESC
            
-- SELECT `Million Plus Cities`, SUM(`Count`) AS deaths
           -- FROM road_accident
		   -- WHERE `Outcome of Incident` LIKE '%Persons Killed%'
           -- GROUP BY `Million Plus Cities`
           -- ORDER BY deaths DESC
           
-- SELECT `Million Plus Cities`, SUM(`Count`) As MinorInjured
            -- FROM road_accident
            -- WHERE `Outcome of Incident` LIKE '%Minor Injury%'
            -- GROUP BY `Million Plus Cities`
            -- ORDER BY  MinorInjured DESC
            
-- SELECT DISTINCT `Cause Subcategory`
-- FROM road_accident;

-- SELECT 
        -- ROUND(
			-- SUM(CASE 
              --  WHEN `Cause Subcategory` IN (
                   -- 'Driving on Wrong side', 'Drunken Driving/ Consumption of alcohol and drug', 'Use of Mobile Phone'
                   -- 'Jumping Red Light'
                -- ) THEN `Count` 
               --  ELSE 0 
           --  END
       -- ) * 100.0 / SUM(`Count`), 2)
     --  AS percent_with_violations
-- FROM road_accident;
            
            

		